<?php

require_once "modelos/producto.php";

class ProductoControlador{
    private $modelo;

    public function __construct()
    {
        $this->modelo= new Producto;
    }

    public function Inicio(){
        require_once "vistas/encabezado.php";
        require_once "vistas/pie.php";
        require_once "vistas/productos/index.php";
        require_once "vistas/pie.php";
    }

    public function FormCrear(){

        $titulo="Registrar";
        $p = new Producto(); // Inicializamos un objeto Producto
    
        if(isset($_GET['id'])){
            // Obtener el producto de la base de datos
            $p = $this->modelo->Obtener($_GET['id']);
            $titulo="Modificar";
        }
        require_once "vistas/encabezado.php";
        require_once "vistas/productos/form.php";
        require_once "vistas/pie.php";
    }
    

    public function Guardar(){
        $p= new Producto();

        // Verificar si los campos están presentes en $_POST antes de asignarlos
        if(isset($_POST['pro_id'])) {
            $p->setPro_id(intval($_POST['pro_id']));
        }
        if(isset($_POST['pro_nom'])) {
            $p->setPro_nom($_POST['pro_nom']);
        }
        if(isset($_POST['pro_mar'])) {
            $p->setPro_mar($_POST['pro_mar']);
        }
        if(isset($_POST['pro_cos'])) {
            $p->setPro_cos(floatval($_POST['pro_cos']));
        }
        if(isset($_POST['pro_pre'])) {
            $p->setPro_pre(floatval($_POST['pro_pre']));
        }
        if(isset($_POST['pro_can'])) {
            $p->setPro_can(intval($_POST['pro_can']));
        }

        // Insertar el producto en la base de datos

        $this->modelo->Insertar($p);

        // Redireccionar a la página de inicio de productos
        header("location:?c=producto");
    }

    public function Borrar(){
        $this->modelo->Eliminar($_GET["id"]);
        header("location:?c=producto");
        
    }

}
?>
