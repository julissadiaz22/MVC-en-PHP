<style>
a{
    color: white;
}

a:hover{
    color: white;
}
</style>

<div class="content-wrapper">
  <div class="page-title">
    <div>
      <h1><i class="fa fa-edit"></i> PRODUCTOS</h1>
      <p><?=$titulo?> Productos</p>
    </div>
    <div>
      <ul class="breadcrumb">
        <li><i class="fa fa-home fa-lg"></i></li>
        <li>Forms</li>
        <li><a href="#">Productos</a></li>
      </ul>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="row">
          <div class="col-lg-11">
            <div class="well bs-component">
              <form class="form-horizontal" method="post" action="?c=producto&a=Guardar">
                <fieldset>
                  <legend><?=$titulo?> Productos</legend>       
                  <!-- Campo para ID del producto (hidden) -->
                  <div class="form-group">
                    <div class="col-lg-10">
                      <input class="form-control" name="pro_id" type="hidden" value="<?=$p->getPro_id()?>">
                    </div>
                  </div>
                  <!-- Campo para Nombre del producto -->
                  <div class="form-group">
                    <label class="col-lg-2 control-label" for="pro_nom">Nombre Producto</label>
                    <div class="col-lg-10">
                      <input class="form-control" name="pro_nom" type="text" placeholder="Ingrese el nombre del producto" value="<?=$p->getPro_nom()?>" required>
                    </div>
                  </div>
                  <!-- Campo para Marca -->
                  <div class="form-group">
                    <label class="col-lg-2 control-label" for="pro_mar">Marca</label>
                    <div class="col-lg-10">
                      <input class="form-control" name="pro_mar" type="text" placeholder="Ingrese la marca del producto" value="<?=$p->getPro_mar()?>" required>
                    </div>
                  </div>
                  <!-- Campo para Costo -->
                  <div class="form-group">
                    <label class="col-lg-2 control-label" for="pro_costo">Costo</label>
                    <div class="col-lg-10">
                      <input class="form-control" name="pro_cos" type="number" step="0.01" placeholder="Ingrese el costo del producto" value="<?=$p->getPro_cos()?>" required>
                    </div>
                  </div>
                  <!-- Campo para Precio -->
                  <div class="form-group">
                    <label class="col-lg-2 control-label" for="pro_precio">Precio</label>
                    <div class="col-lg-10">
                      <input class="form-control" name="pro_pre" type="number" step="0.01" placeholder="Ingrese el precio del producto" value="<?=$p->getPro_pre()?>" required>
                    </div>
                  </div>
                  <!-- Campo para Cantidad -->
                  <div class="form-group">
                    <label class="col-lg-2 control-label" for="pro_cantidad">Cantidad</label>
                    <div class="col-lg-10">
                      <input class="form-control" name="pro_can" type="number" placeholder="Ingrese la cantidad del producto" value="<?=$p->getPro_can()?>" required>
                    </div>
                  </div>
                  
                  <!-- Botones de Cancelar y Enviar -->
                  <div class="form-group">
                    <div class="col-lg-10 col-lg-offset-2">
                      <button class="btn btn-default" type="reset"><a href="?c=producto">Cancelar</button></a>
                      <button class="btn btn-primary" type="submit">Agregar</button>
                    </div>
                  </div>
                </fieldset>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
